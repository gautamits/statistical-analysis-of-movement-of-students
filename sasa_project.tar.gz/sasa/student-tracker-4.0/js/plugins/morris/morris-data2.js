// Morris.js Charts sample data for SB Admin template

$(function() {

    Morris.Bar({
        element: 'CC1',
        data: [{
            Days: 'Monday',
            students: 136
        }, {
            Days: 'Tuesday',
            students: 137
        }, {
            Days: 'Wednesday',
            students: 275
        }, {
            Days: 'Thursday',
            students: 380
        }, {
            Days: 'Friday',
            students: 655
        }, {
            Days: 'Saturday',
            students: 655
        }, {
            Days: 'Sunday',
            students: 655
        }],
        xkey: 'Days',
        ykeys: ['students'],
        labels: ['Students'],
        barRatio: 0.4,
        xLabelAngle: 90,
        hideHover: 'auto',
        resize: true
    });
    
    Morris.Bar({
        element: 'CC2',
        data: [{
            Days: 'Monday',
            students: 136
        }, {
            Days: 'Tuesday',
            students: 137
        }, {
            Days: 'Wednesday',
            students: 275
        }, {
            Days: 'Thursday',
            students: 380
        }, {
            Days: 'Friday',
            students: 655
        }, {
            Days: 'Saturday',
            students: 655
        }, {
            Days: 'Sunday',
            students: 655
        }],
        xkey: 'Days',
        ykeys: ['students'],
        labels: ['Students'],
        barRatio: 0.4,
        xLabelAngle: 90,
        hideHover: 'auto',
        resize: true
    });
    
    Morris.Bar({
        element: 'CC3',
        data: [{
            Days: 'Monday',
            students: 136
        }, {
            Days: 'Tuesday',
            students: 137
        }, {
            Days: 'Wednesday',
            students: 275
        }, {
            Days: 'Thursday',
            students: 380
        }, {
            Days: 'Friday',
            students: 655
        }, {
            Days: 'Saturday',
            students: 655
        }, {
            Days: 'Sunday',
            students: 655
        }],
        xkey: 'Days',
        ykeys: ['students'],
        labels: ['Students'],
        barRatio: 0.4,
        xLabelAngle: 90,
        hideHover: 'auto',
        resize: true
    });
    
    Morris.Bar({
        element: 'library',
        data: [{
            Days: 'Monday',
            students: 136
        }, {
            Days: 'Tuesday',
            students: 137
        }, {
            Days: 'Wednesday',
            students: 275
        }, {
            Days: 'Thursday',
            students: 380
        }, {
            Days: 'Friday',
            students: 655
        }, {
            Days: 'Saturday',
            students: 655
        }, {
            Days: 'Sunday',
            students: 655
        }],
        xkey: 'Days',
        ykeys: ['students'],
        labels: ['Students'],
        barRatio: 0.4,
        xLabelAngle: 90,
        hideHover: 'auto',
        resize: true
    });
    
    Morris.Bar({
        element: 'admin',
        data: [{
            Days: 'Monday',
            students: 136
        }, {
            Days: 'Tuesday',
            students: 137
        }, {
            Days: 'Wednesday',
            students: 275
        }, {
            Days: 'Thursday',
            students: 380
        }, {
            Days: 'Friday',
            students: 655
        }, {
            Days: 'Saturday',
            students: 655
        }, {
            Days: 'Sunday',
            students: 655
        }],
        xkey: 'Days',
        ykeys: ['students'],
        labels: ['Students'],
        barRatio: 0.4,
        xLabelAngle: 90,
        hideHover: 'auto',
        resize: true
    });
    
    Morris.Bar({
        element: 'lt',
        data: [{
            Days: 'Monday',
            students: 136
        }, {
            Days: 'Tuesday',
            students: 137
        }, {
            Days: 'Wednesday',
            students: 275
        }, {
            Days: 'Thursday',
            students: 380
        }, {
            Days: 'Friday',
            students: 655
        }, {
            Days: 'Saturday',
            students: 655
        }, {
            Days: 'Sunday',
            students: 655
        }],
        xkey: 'Days',
        ykeys: ['students'],
        labels: ['Students'],
        barRatio: 0.4,
        xLabelAngle: 90,
        hideHover: 'auto',
        resize: true
    });
    
    Morris.Bar({
        element: 'bh',
        data: [{
            Days: 'Monday',
            students: 136
        }, {
            Days: 'Tuesday',
            students: 137
        }, {
            Days: 'Wednesday',
            students: 275
        }, {
            Days: 'Thursday',
            students: 380
        }, {
            Days: 'Friday',
            students: 655
        }, {
            Days: 'Saturday',
            students: 655
        }, {
            Days: 'Sunday',
            students: 655
        }],
        xkey: 'Days',
        ykeys: ['students'],
        labels: ['Students'],
        barRatio: 0.4,
        xLabelAngle: 90,
        hideHover: 'auto',
        resize: true
    });
    
    Morris.Bar({
        element: 'gh',
        data: [{
            Days: 'Monday',
            students: 136
        }, {
            Days: 'Tuesday',
            students: 137
        }, {
            Days: 'Wednesday',
            students: 275
        }, {
            Days: 'Thursday',
            students: 380
        }, {
            Days: 'Friday',
            students: 655
        }, {
            Days: 'Saturday',
            students: 655
        }, {
            Days: 'Sunday',
            students: 655
        }],
        xkey: 'Days',
        ykeys: ['students'],
        labels: ['Students'],
        barRatio: 0.4,
        xLabelAngle: 90,
        hideHover: 'auto',
        resize: true
    });
    
    Morris.Bar({
        element: 'sp',
        data: [{
            Days: 'Monday',
            students: 136
        }, {
            Days: 'Tuesday',
            students: 137
        }, {
            Days: 'Wednesday',
            students: 275
        }, {
            Days: 'Thursday',
            students: 380
        }, {
            Days: 'Friday',
            students: 655
        }, {
            Days: 'Saturday',
            students: 655
        }, {
            Days: 'Sunday',
            students: 655
        }],
        xkey: 'Days',
        ykeys: ['students'],
        labels: ['Students'],
        barRatio: 0.4,
        xLabelAngle: 90,
        hideHover: 'auto',
        resize: true
    });


});
