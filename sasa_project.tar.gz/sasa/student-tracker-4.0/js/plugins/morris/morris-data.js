// Morris.js Charts sample data for SB Admin template

$(function() {

    // Area Chart
    Morris.Area({
        element: 'morris-area-chart',
        data: [{
            time: '06:00',
            CC3: 2666,
            CC2: null,
            CC1: 2647
        }, {
            time: '09:45',
            CC3: 2778,
            CC2: 2294,
            CC1: 2441
        }, {
            time: '12:00',
            CC3: 4912,
            CC2: 1969,
            CC1: 2501
        }, {
            time: '14:30',
            CC3: 3767,
            CC2: 3597,
            CC1: 5689
        }, {
            time: '16:00',
            CC3: 6810,
            CC2: 1914,
            CC1: 2293
        }, {
            time: '19:00',
            CC3: 5670,
            CC2: 4293,
            CC1: 1881
        }, {
            time: '22:00',
            CC3: 4820,
            CC2: 3795,
            CC1: 1588
        }, {
            time: '23:00',
            CC3: 15073,
            CC2: 5967,
            CC1: 5175
        }, {
            time: '23:30',
            CC3: 10687,
            CC2: 4460,
            CC1: 2028
        }, {
            time: '24:40',
            CC3: 8432,
            CC2: 5713,
            CC1: 1791
        }],
        xkey: 'time',
        ykeys: ['CC3', 'CC2', 'CC1'],
        labels: ['CC3', 'CC2', 'CC1'],
        pointSize: 2,
        hideHover: 'auto',
        resize: true
    });
    
    //2nd chart with days and building
    
     Morris.Area({
        element: 'morris-area-chart2',
        data: [{
            day: '1 Monday',
            CC3: 2666,
            CC2: 1400,
            CC1: 2647,
            LT: 1600,
            Library: 2000,
            Admin: 1000,
            BH: 5000
        }, {
            day: '2 Tuesday',
            CC3: 2778,
            CC2: 2294,
            CC1: 2441,
            LT: 1600,
            Library: 2000,
            Admin: 1000,
            BH: 5000
        }, {
            day: '3 Wednesday',
            CC3: 4912,
            CC2: 1969,
            CC1: 2501,
            LT: 1600,
            Library: 2000,
            Admin: 1000,
            BH: 5000
        }, {
            day: '4 Thursday',
            CC3: 3767,
            CC2: 3597,
            CC1: 5689,
            LT: 1600,
            Library: 2000,
            Admin: 1000,
            BH: 5000
        }, {
            day: '5 Friday',
            CC3: 6810,
            CC2: 1914,
            CC1: 2293,
            LT: 1600,
            Library: 2000,
            Admin: 1000,
            BH: 5000
        }, {
            day: '6 Saturday',
            CC3: 5670,
            CC2: 4293,
            CC1: 1881,
            LT: 1600,
            Library: 2000,
            Admin: 1000,
            BH: 5000
        }, {
            day: '7 Sunday',
            CC3: 4820,
            CC2: 3795,
            CC1: 1588,
            LT: 1600,
            Library: 2000,
            Admin: 1000,
            BH: 5000
        }],
        xkey: 'day',
        ykeys: ['CC3', 'CC2', 'CC1','LT','Library','Admin','BH'],
        labels: ['CC3', 'CC2', 'CC1','LT','Library','Admin','BH'],
        pointSize: 2,
        hideHover: 'auto',
        resize: true
    });
    
      


    // Donut Chart
    Morris.Donut({
        element: 'morris-donut-chart',
        data: [{
            label: "Inside hostel",
            value: 2000
        }, {
            label: "Outside college",
            value: 500
        }, {
            label: "Inside college",
            value: 1000
        }],
        resize: true
    });

    // Line Chart
    Morris.Line({
        // ID of the element in which to draw the chart.
        element: 'morris-line-chart',
        // Chart data records -- each entry in this array corresponds to a point on
        // the chart.
        data: [{
            d: '2012-10-01',
            logs: 802
        }, {
            d: '2012-10-02',
            logs: 783
        }, {
            d: '2012-10-03',
            logs: 820
        }, {
            d: '2012-10-04',
            logs: 839
        }, {
            d: '2012-10-05',
            logs: 792
        }, {
            d: '2012-10-06',
            logs: 859
        }, {
            d: '2012-10-07',
            logs: 790
        }, {
            d: '2012-10-08',
            logs: 1680
        }, {
            d: '2012-10-09',
            logs: 1592
        }, {
            d: '2012-10-10',
            logs: 1420
        }, {
            d: '2012-10-11',
            logs: 882
        }, {
            d: '2012-10-12',
            logs: 889
        }, {
            d: '2012-10-13',
            logs: 819
        }, {
            d: '2012-10-14',
            logs: 849
        }, {
            d: '2012-10-15',
            logs: 870
        }, {
            d: '2012-10-16',
            logs: 1063
        }, {
            d: '2012-10-17',
            logs: 1192
        }, {
            d: '2012-10-18',
            logs: 1224
        }, {
            d: '2012-10-19',
            logs: 1329
        }, {
            d: '2012-10-20',
            logs: 1329
        }, {
            d: '2012-10-21',
            logs: 1239
        }, {
            d: '2012-10-22',
            logs: 1190
        }, {
            d: '2012-10-23',
            logs: 1312
        }, {
            d: '2012-10-24',
            logs: 1293
        }, {
            d: '2012-10-25',
            logs: 1283
        }, {
            d: '2012-10-26',
            logs: 1248
        }, {
            d: '2012-10-27',
            logs: 1323
        }, {
            d: '2012-10-28',
            logs: 1390
        }, {
            d: '2012-10-29',
            logs: 1420
        }, {
            d: '2012-10-30',
            logs: 1529
        }, {
            d: '2012-10-31',
            logs: 1892
        }, ],
        // The name of the data record attribute that contains x-visitss.
        xkey: 'd',
        // A list of names of data record attributes that contain y-visitss.
        ykeys: ['logs'],
        // Labels for the ykeys -- will be displayed when you hover over the
        // chart.
        labels: ['Logs'],
        // Disables line smoothing
        smooth: false,
        resize: true
    });
    
    //line 2
    
    // Line Chart
    Morris.Line({
        // ID of the element in which to draw the chart.
        element: 'comp',
        // Chart data records -- each entry in this array corresponds to a point on
        // the chart.
        data: [{
            building: '1 CC1',
            logst: 802,
            logsl: 902
        }, {
            building: '2 CC2',
            logst: 783,
            logsl: 902
        }, {
            building: '3 CC3',
            logst: 820,
            logsl: 902
        }, {
            building: '4 Library',
            logst: 1680,
            logsl: 902
        }, {
            building: '5 Swiming pool',
            logst: 1592,
            logsl: 902
        }, {
            building: '6 Boys Hostel',
            logst: 1420,
            logsl: 902
        }, {
            building: '7 Girls hostel',
            logst: 882,
            logsl: 902
        }, {
            building: '9 Admin',
            logst: 889,
            logsl: 902
        }, {
            building: '10 Lecture theatre',
            logst: 849,
            logsl: 902
        }],
        // The name of the data record attribute that contains x-visitss.
        xkey: 'building',
        // A list of names of data record attributes that contain y-visitss.
        ykeys: ['logst','logsl'],
        // Labels for the ykeys -- will be displayed when you hover over the
        // chart.
        labels: ['Logs This week', 'Logs Last week'],
        // Disables line smoothing
        smooth: false,
        resize: true
    });
    
    

    // Bar Chart
    Morris.Bar({
        element: 'morris-bar-chart',
        data: [{
            building: 'CC1',
            students: 136
        }, {
            building: 'CC2',
            students: 137
        }, {
            building: 'CC3',
            students: 275
        }, {
            building: 'LT',
            students: 380
        }, {
            building: 'AD',
            students: 655
        }, {
            building: 'BH',
            students: 1571
        }, {
            building: 'SP',
            students: 655
        }, {
            building: 'Library',
            students: 655
        }],
        xkey: 'building',
        ykeys: ['students'],
        labels: ['Students'],
        barRatio: 0.4,
        xLabelAngle: 90,
        hideHover: 'auto',
        resize: true
    });
    
    //bh bar chart
    
    Morris.Bar({
        element: 'morris-bar-chart2',
        data: [{
            building: 'BH1',
            students: 136
        }, {
            building: 'BH2',
            students: 137
        }, {
            building: 'BH3',
            students: 275
        }, {
            building: 'BH4',
            students: 380
        }, {
            building: 'BH5',
            students: 655
        }],
        xkey: 'building',
        ykeys: ['students'],
        labels: ['Students'],
        barRatio: 0.4,
        xLabelAngle: 90,
        hideHover: 'auto',
        resize: true
    });
    
    //per hour density
     Morris.Bar({
        element: 'morris-bar-chart3',
        data: [{
            Hour: '09:00',
            students: 136
        }, {
            Hour: '10:00',
            students: 137
        }, {
            Hour: '11:00',
            students: 275
        }, {
            Hour: '12:00',
            students: 380
        }, {
            Hour: '13:00',
            students: 655
        }, {
            Hour: '14:00',
            students: 655
        }, {
            Hour: '15:00',
            students: 655
        }, {
            Hour: '16:00',
            students: 655
        }, {
            Hour: '17:00',
            students: 655
        }, {
            Hour: '18:00',
            students: 655
        }],
        xkey: 'Hour',
        ykeys: ['students'],
        labels: ['Students'],
        barRatio: 0.4,
        xLabelAngle: 90,
        hideHover: 'auto',
        resize: true
    });
    
    


});
