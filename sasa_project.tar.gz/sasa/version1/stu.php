<html>
<head>Search student</head>
<body>
	<div>
	<?php
		echo '
		<form action = "search.php" method = "post">
		<input type = "text" name = "search"  placeholder = "search friends"></input>
		<input type = "submit"  value = "search user">
		</form>';
	?>
	</div>
</body>
</html>